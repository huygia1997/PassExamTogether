package pet.project.pet.model;

import javax.xml.transform.Result;

public class ResObj {
    private boolean message;
    private Result result;

    public boolean isMessage() {
        return message;
    }

    public void setMessage(boolean message) {
        this.message = message;
    }
}
